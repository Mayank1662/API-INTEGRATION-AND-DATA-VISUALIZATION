# AI Chatbot with NLP (spaCy)

A minimal Python chatbot using spaCy to match intents and respond.

## How to Run

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Run the chatbot:
```bash
python chatbot.py
```

Type `quit` to exit.

## Files

- `chatbot.py` – Main Python script
- `intents.json` – Patterns & responses
- `requirements.txt` – Python dependencies
